import{c as o}from"./index-B5-7efjG.js";const n=[["path",{d:"M6 9l6 6l6 -6",key:"svg-0"}]],t=o("outline","chevron-down","ChevronDown",n);export{t as I};
