import{c as o}from"./index-B5-7efjG.js";const t=[["path",{d:"M18 6l-12 12",key:"svg-0"}],["path",{d:"M6 6l12 12",key:"svg-1"}]],c=o("outline","x","X",t);export{c as I};
