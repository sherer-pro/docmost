const e="_editor_1hxbq_1",i="_editorWithFixedToolbar_1hxbq_12",o="_readingTime_1hxbq_20",t={editor:e,editorWithFixedToolbar:i,readingTime:o};export{t as e};
