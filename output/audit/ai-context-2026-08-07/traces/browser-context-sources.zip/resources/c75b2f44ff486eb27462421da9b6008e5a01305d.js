import{c}from"./index-B5-7efjG.js";const e=[["path",{d:"M5 12l5 5l10 -10",key:"svg-0"}]],t=c("outline","check","Check",e);export{t as I};
