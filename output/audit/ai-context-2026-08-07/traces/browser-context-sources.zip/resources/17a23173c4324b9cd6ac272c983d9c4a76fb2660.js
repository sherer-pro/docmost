function n(o){return t=>{const r=o.safeParse(t);if(r.success)return{};const s={};return r.error.errors.forEach(e=>{s[e.path.join(".")]=e.message}),s}}export{n as z};
